sudo apt udate && upgrade
sudo apt install curl
curl https://raw.githubusercontent.com/creationix/nvm/master/install.sh | bash
source ~/.profile
nvm install nodejs
sudo apt install ffmpeg
sudo apt install ffmpeg
nvm ls-remote
